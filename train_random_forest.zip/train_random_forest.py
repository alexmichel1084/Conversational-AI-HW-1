import optuna
import re
import json
import nltk
import pandas as pd
import pickle
from nltk.corpus import stopwords
nltk.download('stopwords')
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.ensemble import RandomForestClassifier

# get and prepare data to preprocessing

data = pd.read_csv('Ethos_Dataset_Binary.csv', delimiter=';', header=None)
data = data[data[0] != 'comment']
# print(data)

# get features and labels
features = data[0].values
labels = data[1].astype('float').round(0).values
# print(labels)

# preprocessing data
processed_features = []
for sentence in range(0, len(features)):
    # Remove all the special characters
    processed_feature = re.sub(r'\W', ' ', str(features[sentence]))

    # remove all single characters
    processed_feature = re.sub(r'\s+[a-zA-Z]\s+', ' ', processed_feature)

    # Remove single characters from the start
    processed_feature = re.sub(r'\^[a-zA-Z]\s+', ' ', processed_feature)

    # Substituting multiple spaces with single space
    processed_feature = re.sub(r'\s+', ' ', processed_feature, flags=re.I)

    # Removing prefixed 'b'
    processed_feature = re.sub(r'^b\s+', '', processed_feature)

    # Converting to Lowercase
    processed_feature = processed_feature.lower()

    processed_features.append(processed_feature)


# print(processed_features)
experiments = []

def objective(trial: optuna.Trial):

    params = {
        "number": trial.number,
        "max_features": trial.suggest_int("max_features", 1000, 5000),
        "max_df": trial.suggest_float("max_df", 0.75, 0.9),
        "n_estimators": trial.suggest_int("n_estimators", 100, 500),
        "test_size": trial.suggest_float("test_size", 0.1, 0.3),
        "score": 0
    }



    vectorizer = TfidfVectorizer(max_features=params["max_features"], min_df=0.0001, max_df=params["max_df"],
                                 stop_words=stopwords.words('english'))
    features = vectorizer.fit_transform(processed_features).toarray()

    # split data to train
    X_train, X_test, y_train, y_test = train_test_split(-features, labels, test_size=params["test_size"],
                                                        random_state=0)

    # download classifier
    text_classifier = RandomForestClassifier(n_estimators=params["n_estimators"], random_state=0)
    # train
    text_classifier.fit(X_train, y_train)

    # eval metrics
    predictions = text_classifier.predict(X_test)

    #    print(confusion_matrix(y_test, predictions))
    #    print(classification_report(y_test, predictions))
    #    print(accuracy_score(y_test, predictions))
    params["score"] = accuracy_score(y_test, predictions)
    experiments.append(params)
    return accuracy_score(y_test, predictions), params["n_estimators"]

def save_model(params):

    vectorizer = TfidfVectorizer(max_features=params["max_features"], min_df=0.0001, max_df=params["max_df"],
                                 stop_words=stopwords.words('english'))
    features = vectorizer.fit_transform(processed_features).toarray()
    # download vectorizer
    # pickle.dump(vectorizer.vocabulary_, open("feature.pkl", "wb"))

    # split data to train
    X_train, X_test, y_train, y_test = train_test_split(-features, labels, test_size=params["test_size"], random_state=0)

    # download classifier
    text_classifier = RandomForestClassifier(n_estimators=params["n_estimators"], random_state=0)
    # train
    text_classifier.fit(X_train, y_train)
    # save model
    with open('rf_model_1', 'wb') as f:
        pickle.dump(text_classifier, f)







study = optuna.create_study(directions=['maximize', 'minimize'])
study.optimize(objective, n_trials=100)

f = open('logs.txt', 'a')
for i in experiments:
    print(str(json.dumps(i)))
    f.write("\n"+str(json.dumps(i))+"\n")
f.close()

json_params = json.dumps(study.best_trials[0].params)
with open('data.txt', 'w') as outfile:
    json.dump(json_params, outfile)

save_model(study.best_trials[0].params)
